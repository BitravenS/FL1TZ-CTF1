void _init()
{
    if (__gmon_start__)
        __gmon_start__();
}

int64_t sub_1020()
{
    int64_t var_8 = data_3ff0;
    /* jump -> data_3ff8 */
}

int32_t printf(char const* format, ...)
{
    /* tailcall */
    return printf();
}

int64_t sub_1036()
{
    int64_t var_8 = 0;
    /* tailcall */
    return sub_1020();
}

uint64_t strcspn(char const* arg1, char const* arg2)
{
    /* tailcall */
    return strcspn(arg1, arg2);
}

int64_t sub_1046()
{
    int64_t var_8 = 1;
    /* tailcall */
    return sub_1020();
}

int32_t sprintf(char* s, char const* format, ...)
{
    /* tailcall */
    return sprintf();
}

int64_t sub_1056()
{
    int64_t var_8 = 2;
    /* tailcall */
    return sub_1020();
}

char* strstr(char const* arg1, char const* arg2)
{
    /* tailcall */
    return strstr(arg1, arg2);
}

int64_t sub_1066()
{
    int64_t var_8 = 3;
    /* tailcall */
    return sub_1020();
}

uint64_t strlen(char const* arg1)
{
    /* tailcall */
    return strlen(arg1);
}

int64_t sub_1076()
{
    int64_t var_8 = 4;
    /* tailcall */
    return sub_1020();
}

int64_t EVP_DigestFinal_ex()
{
    /* tailcall */
    return EVP_DigestFinal_ex();
}

int64_t sub_1086()
{
    int64_t var_8 = 5;
    /* tailcall */
    return sub_1020();
}

clock_t clock()
{
    /* tailcall */
    return clock();
}

int64_t sub_1096()
{
    int64_t var_8 = 6;
    /* tailcall */
    return sub_1020();
}

int64_t EVP_DigestInit_ex()
{
    /* tailcall */
    return EVP_DigestInit_ex();
}

int64_t sub_10a6()
{
    int64_t var_8 = 7;
    /* tailcall */
    return sub_1020();
}

int32_t fclose(FILE* fp)
{
    /* tailcall */
    return fclose(fp);
}

int64_t sub_10b6()
{
    int64_t var_8 = 8;
    /* tailcall */
    return sub_1020();
}

void __stack_chk_fail() __noreturn
{
    /* tailcall */
    return __stack_chk_fail();
}

int64_t sub_10c6()
{
    int64_t var_8 = 9;
    /* tailcall */
    return sub_1020();
}

int64_t EVP_MD_CTX_new()
{
    /* tailcall */
    return EVP_MD_CTX_new();
}

int64_t sub_10d6()
{
    int64_t var_8 = 0xa;
    /* tailcall */
    return sub_1020();
}

FILE* fopen(char const* filename, char const* mode)
{
    /* tailcall */
    return fopen(filename, mode);
}

int64_t sub_10e6()
{
    int64_t var_8 = 0xb;
    /* tailcall */
    return sub_1020();
}

void exit(int32_t status) __noreturn
{
    /* tailcall */
    return exit(status);
}

int64_t sub_10f6()
{
    int64_t var_8 = 0xc;
    /* tailcall */
    return sub_1020();
}

char* getenv(char const* name)
{
    /* tailcall */
    return getenv(name);
}

int64_t sub_1106()
{
    int64_t var_8 = 0xd;
    /* tailcall */
    return sub_1020();
}

int32_t putchar(int32_t c)
{
    /* tailcall */
    return putchar(c);
}

int64_t sub_1116()
{
    int64_t var_8 = 0xe;
    /* tailcall */
    return sub_1020();
}

int32_t strcmp(char const* arg1, char const* arg2)
{
    /* tailcall */
    return strcmp(arg1, arg2);
}

int64_t sub_1126()
{
    int64_t var_8 = 0xf;
    /* tailcall */
    return sub_1020();
}

int64_t getppid()
{
    /* tailcall */
    return getppid();
}

int64_t sub_1136()
{
    int64_t var_8 = 0x10;
    /* tailcall */
    return sub_1020();
}

int32_t puts(char const* str)
{
    /* tailcall */
    return puts(str);
}

int64_t sub_1146()
{
    int64_t var_8 = 0x11;
    /* tailcall */
    return sub_1020();
}

int32_t atoi(char const* nptr)
{
    /* tailcall */
    return atoi(nptr);
}

int64_t sub_1156()
{
    int64_t var_8 = 0x12;
    /* tailcall */
    return sub_1020();
}

int32_t fgetc(FILE* fp)
{
    /* tailcall */
    return fgetc(fp);
}

int64_t sub_1166()
{
    int64_t var_8 = 0x13;
    /* tailcall */
    return sub_1020();
}

char* fgets(char* buf, int32_t n, FILE* fp)
{
    /* tailcall */
    return fgets(buf, n, fp);
}

int64_t sub_1176()
{
    int64_t var_8 = 0x14;
    /* tailcall */
    return sub_1020();
}

int32_t snprintf(char* s, uint64_t maxlen, char const* format, ...)
{
    /* tailcall */
    return snprintf();
}

int64_t sub_1186()
{
    int64_t var_8 = 0x15;
    /* tailcall */
    return sub_1020();
}

int64_t fstat()
{
    /* tailcall */
    return fstat();
}

int64_t sub_1196()
{
    int64_t var_8 = 0x16;
    /* tailcall */
    return sub_1020();
}

int64_t EVP_sha256()
{
    /* tailcall */
    return EVP_sha256();
}

int64_t sub_11a6()
{
    int64_t var_8 = 0x17;
    /* tailcall */
    return sub_1020();
}

int64_t EVP_MD_CTX_free()
{
    /* tailcall */
    return EVP_MD_CTX_free();
}

int64_t sub_11b6()
{
    int64_t var_8 = 0x18;
    /* tailcall */
    return sub_1020();
}

int64_t EVP_DigestUpdate()
{
    /* tailcall */
    return EVP_DigestUpdate();
}

int64_t sub_11c6()
{
    int64_t var_8 = 0x19;
    /* tailcall */
    return sub_1020();
}

int64_t ptrace(enum __ptrace_request request, ...)
{
    /* tailcall */
    return ptrace();
}

void _start(int64_t arg1, int64_t arg2, void (* arg3)()) __noreturn
{
    int64_t stack_end_1;
    int64_t stack_end = stack_end_1;
    __libc_start_main(main, __return_addr, &ubp_av, nullptr, nullptr, arg3, &stack_end);
    /* no return */
}

void deregister_tm_clones()
{
    return;
}

void sub_1240()
{
    return;
}

void _FINI_0()
{
    if (data_40e8)
        return;
    
    if (__cxa_finalize)
        __cxa_finalize(__dso_handle);
    
    deregister_tm_clones();
    data_40e8 = 1;
}

void _INIT_0()
{
    /* tailcall */
    return sub_1240();
}

uint64_t vx8321()
{
    int64_t (* const var_10)(enum __ptrace_request request, ...) = ptrace;
    uint64_t result = (ptrace + 0x22) & 0xfff;
    
    if (result != 0xabc)
        return result;
    
    exit(1);
    /* no return */
}

int64_t kp9274()
{
    void* fsbase;
    int64_t rax = *(fsbase + 0x28);
    void var_a8;
    fstat(0, &var_a8);
    int32_t var_90;
    
    if ((var_90 & 0xf000) != 0x2000)
    {
        exit(1);
        /* no return */
    }
    
    int32_t var_b8 = 0;
    
    for (int32_t i = 0; i <= 4; i += 1)
        var_b8 += i;
    
    if (var_b8 != 0xa)
        *0xdeadbeef = 0;
    
    if (rax == *(fsbase + 0x28))
        return rax - *(fsbase + 0x28);
    
    __stack_chk_fail();
    /* no return */
}

uint64_t qt6013()
{
    int0_t tsc;
    int32_t temp0;
    temp0 = _rdtsc(tsc);
    int32_t temp1;
    uint64_t result = temp0 | temp1 << 0x20;
    
    for (int32_t i = 0; i <= 0x3e7; i += 1)
    {
    }
    
    int32_t temp0_1;
    temp0_1 = _rdtsc(tsc);
    
    if ((temp0_1 | temp1 << 0x20) - result <= 0x7a120)
        return result;
    
    exit(1);
    /* no return */
}

int64_t sr654h()
{
    void* fsbase;
    int64_t rax = *(fsbase + 0x28);
    
    if (ptrace(PTRACE_TRACEME, 0, 0, 0) == -1)
    {
        exit(1);
        /* no return */
    }
    
    int64_t name;
    __builtin_strcpy(&name, "+.:/=<&+&>");
    int32_t var_384 = 0;
    
    while (*(&name + var_384))
    {
        *(&name + var_384) ^= 0x5a;
        var_384 += 1;
    }
    
    if (getenv(&name))
    {
        exit(1);
        /* no return */
    }
    
    FILE* fp = fopen("/proc/self/status", u"r…");
    void buf;
    
    while (fgets(&buf, 0x100, fp))
    {
        void nptr;
        
        if (strstr(&buf, "TracerPid") && atoi(&nptr) > 0)
        {
            exit(1);
            /* no return */
        }
    }
    
    fclose(fp);
    clock_t rax_17 = clock();
    int32_t i;
    
    for (i = 0; i <= 0xf423f; i += 1)
    {
    }
    
    if (clock() - rax_17 <= 0x3e7)
    {
        exit(1);
        /* no return */
    }
    
    int32_t rax_24 = getppid();
    int32_t var_33a = 0xc5d8da85;
    var_33a = 0x85c9c5;
    int64_t var_32c = -0x303b3c393138367b;
    char var_324 = 0;
    int32_t var_380 = 0;
    
    while (*(&var_33a + var_380))
    {
        *(&var_33a + var_380) ^= 0xaa;
        var_380 += 1;
    }
    
    int32_t var_37c = 0;
    
    while (*(&var_32c + var_37c))
    {
        *(&var_32c + var_37c) ^= 0xaa;
        var_37c += 1;
    }
    
    void var_218;
    snprintf(&var_218, 0x100, "%s%d%s", &var_33a, rax_24, &var_32c, i, var_380);
    FILE* fp_1 = fopen(&var_218, u"r…");
    int32_t var_333;
    void buf_1;
    
    if (fp_1)
    {
        fgets(&buf_1, 0x100, fp_1);
        int32_t var_33e = 0xc8cecd;
        var_333 = 0xcbd8ded9;
        var_333 = 0xcfc9cb;
        int32_t var_378_1 = 0;
        
        while (*(&var_33e + var_378_1))
        {
            *(&var_33e + var_378_1) ^= 0xaa;
            var_378_1 += 1;
        }
        
        int32_t var_374_1 = 0;
        
        while (*(&var_333 + var_374_1))
        {
            *(&var_333 + var_374_1) ^= 0xaa;
            var_374_1 += 1;
        }
        
        char* rax_62 = strstr(&buf_1, &var_33e);
        char* rax_63;
        
        if (!rax_62)
            rax_63 = strstr(&buf_1, &var_333);
        
        if (rax_62 || rax_63)
        {
            exit(1);
            /* no return */
        }
        
        fclose(fp_1);
    }
    
    vx8321();
    kp9274();
    qt6013();
    var_333 = 0xd8cac9cc;
    var_333 = 0xcac3d8;
    int32_t var_370 = 0;
    
    while (*(&var_333 + var_370))
    {
        *(&var_333 + var_370) ^= 0xaa;
        var_370 += 1;
    }
    
    FILE* fp_2 = fopen("/proc/self/maps", u"r…");
    
    if (fp_2)
    {
        while (true)
        {
            if (!fgets(&buf_1, 0x100, fp_2))
            {
                fclose(fp_2);
                break;
            }
            
            if (strstr(&buf_1, &var_333))
            {
                exit(1);
                /* no return */
            }
        }
    }
    
    if (rax == *(fsbase + 0x28))
        return rax - *(fsbase + 0x28);
    
    __stack_chk_fail();
    /* no return */
}

int64_t abc123_def456(char* arg1, int64_t arg2)
{
    int64_t rax = EVP_MD_CTX_new();
    EVP_DigestInit_ex(rax, EVP_sha256(), 0);
    EVP_DigestUpdate(rax, arg1, strlen(arg1));
    EVP_DigestFinal_ex(rax, arg2, 0);
    return EVP_MD_CTX_free(rax);
}

void ghi789_jkl012(void* arg1, int64_t arg2)
{
    for (int32_t i = 0; i <= 0x1f; i += 1)
        sprintf(i * 2 + arg2, "%02x", *(arg1 + i));
}

uint64_t print_ln(int64_t arg1, int64_t arg2) __pure
{
    uint64_t rax_1 = arg2 >> 0x3f;
    int64_t rax_4;
    rax_4 = !rax_1;
    int64_t i_1 = (-(rax_4) & arg2) + -(arg2) * rax_1;
    uint64_t rax_9 = arg1 >> 0x3f;
    int64_t rax_12;
    rax_12 = !rax_9;
    int64_t rax_16 = (-(rax_12) & arg1) + -(arg1) * rax_9;
    int64_t var_80 = rax_16;
    uint64_t var_78 = ((rax_16 << 2 ^ i_1) | i_1 >> 2) & 0xf;
    int64_t var_70 = var_80;
    
    for (int64_t i = i_1; var_70 >= i; i = i_1)
    {
        var_80 = (var_80 - i_1) ^ var_78 ^ var_78;
        var_78 = (var_78 * 2) | var_78 >> 3;
        var_70 = var_80;
    }
    
    int64_t rax_44;
    rax_44 = (var_80 ^ var_78) == var_78;
    return rax_44;
}

int32_t main(int32_t argc, char** argv, char** envp)
{
    void* fsbase;
    int64_t rax = *(fsbase + 0x28);
    sr654h();
    printf("pass ? ");
    void buf;
    int32_t result;
    
    if (fgets(&buf, 0x64, __TMC_END__))
    {
        *(&buf + strcspn(&buf, u"\n…")) = 0;
        void var_178;
        abc123_def456("FL1TZ{y4_w3ld1_Jib_elFl4g_mel_MAZE}", &var_178);
        void var_138;
        ghi789_jkl012(&var_178, &var_138);
        int64_t s;
        __builtin_memset(&s, 0, 0x64);
        int32_t var_194_1 = 0;
        int32_t var_190_1 = 0;
        
        while (*(&var_138 + var_194_1))
        {
            if (print_ln(*(&var_138 + var_194_1), 4))
            {
                *(&s + var_190_1) = *(&var_138 + var_194_1);
                var_190_1 += 1;
            }
            
            var_194_1 += 1;
        }
        
        *(&s + var_190_1) = 0;
        
        if (strcmp(&buf, &s))
        {
            puts("dsl");
            result = 0;
        }
        else
        {
            FILE* fp = fopen("flag.txt", u"r…");
            
            if (fp)
            {
                while (true)
                {
                    char rax_24 = fgetc(fp);
                    
                    if (rax_24 == 0xff)
                        break;
                    
                    putchar(rax_24);
                }
                
                fclose(fp);
                result = 0;
            }
            else
            {
                puts("Error opening file");
                result = 1;
            }
        }
    }
    else
    {
        puts("Error reading input");
        result = 1;
    }
    
    *(fsbase + 0x28);
    
    if (rax == *(fsbase + 0x28))
        return result;
    
    __stack_chk_fail();
    /* no return */
}

int64_t _fini() __pure
{
    return;
}

